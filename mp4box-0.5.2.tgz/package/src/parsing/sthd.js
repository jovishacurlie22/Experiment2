BoxParser.createFullBoxCtor("sthd");

